﻿namespace ProjectLoc.Models
{
    public class Printer
    {
        public int Id { get; set; }
        public string DeviceId { get; set; }
        public string Name { get; set; }
        public string PrinterColor { get; set; }
        public int TeamId { get; set; }
    }
}

﻿namespace ProjectLoc.Dtos.Printer
{
    public class CreatePrinterDTO
    {
        public string DeviceId { get; set; }
        public string Name { get; set; }
        public string PrinterColor { get; set; }
        public int TeamId { get; set; }
    }
}

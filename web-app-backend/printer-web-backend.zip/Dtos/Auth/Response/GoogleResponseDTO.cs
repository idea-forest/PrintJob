namespace ProjectLoc.Dtos.Auth.Response;

public class GoogleResponseDTO : AuthResult
{

}

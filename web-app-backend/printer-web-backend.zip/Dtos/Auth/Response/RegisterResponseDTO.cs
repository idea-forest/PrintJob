namespace ProjectLoc.Dtos.Auth.Response;

public class RegisterResponseDTO : AuthResult
{

}

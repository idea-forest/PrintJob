namespace ProjectLoc.Dtos.Auth.Response;

public class LoginResponseDTO : AuthResult
{

}

﻿using Microsoft.AspNetCore.SignalR;

namespace ProjectLoc.Services
{
    public class DashboardHub : Hub
    {
    }
}

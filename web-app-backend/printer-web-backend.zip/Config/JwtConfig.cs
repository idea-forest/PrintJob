namespace ProjectLoc.Config;

public class JwtConfig
{
    public string? Secret { get; set; }
}
